---
PDC-ID: "FOREST-MAP-SPEC"
UUID: "<GENERATE-UUID>"
Canonical-Path: "governance/specifications/FOREST-MAP-SPEC.md"

Title: "Voice of the Forest Navigation Specification"
Record-Type: "Specification"
Version: "0.2.0"
Status: "Working Draft"
Season: "Spring"
Growth-Ring: "Draft 11"

Authors:
  - "maciono brown"
---

# Voice of the Forest Navigation Specification

## Purpose

Define the Spirit of the Forest, the Voice of the Forest, the centralized Forest Command Grove, the Forest Compass, the Forest Map, and the Path Finder.

## Navigation Chain

The standard document navigation chain is:

```text
Document Identity
→ Document Title
→ Spirit of the Forest
  → Voice of the Forest
    → Forest Command Grove
    → Forest Compass
    → Forest Map
    → Path Finder
→ Main Content
→ Paths and Relationships
→ Forest Signature
```

This is a navigation order. It does not replace the governance hierarchy.

## Spirit of the Forest

The Spirit of the Forest is the guiding and assisting layer of the Forest.

It SHALL:

- Help orient the user
- Make commands easy to locate
- Offer Paths and choices
- Warn about broken, unhealthy, or dangerous Paths when known
- Preserve user authority
- Avoid presenting guidance as compulsory

The Spirit communicates through the Voice of the Forest.

## Voice of the Forest

The Voice of the Forest is the user-facing expression of the Spirit.

It SHALL contain or provide access to:

- The Forest Command Grove
- The Forest Compass
- The Forest Map
- The Path Finder

The Voice SHALL remain understandable without specialized software.

## Forest Command Grove

The Forest Command Grove is the canonical command index.

It SHALL:

- Gather all approved Forest commands in one place
- Organize commands by function
- Preserve exact canonical command wording
- Distinguish approved commands from proposed commands
- Remain synchronized with command explanations elsewhere

## Forest Compass

The Forest Compass provides orientation.

It SHOULD identify:

- Current PDC-ID
- UUID
- Canonical path
- Current location
- Map status
- Active Predestined Path
- Nearby Paths
- Suggested next stops

## Forest Map

The Forest Map provides a living Tree of the current file.

It SHALL:

- Reflect the current heading hierarchy
- Update when the file changes
- Preserve readable section names
- Avoid replacing canonical IDs and Paths
- Remain enclosed by generated-map markers
- Remain understandable without special software

## Path Finder

The Path Finder creates, inspects, saves, follows, pauses, changes, and completes Paths.

It SHALL:

- Support ordinary and Predestined Paths
- Require user approval before activating a Tree-proposed route
- Permit detours and divergence
- Preserve progress
- Show required and optional stops
- Provide the next stop without hiding alternatives

## Predestined Paths

A Predestined Path is a user-controlled route planned in advance.

Valid states include:

- Proposed
- Active
- Paused
- Diverged
- Completed
- Abandoned

A Predestined Path guides the traveler. It does not trap the traveler.

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
