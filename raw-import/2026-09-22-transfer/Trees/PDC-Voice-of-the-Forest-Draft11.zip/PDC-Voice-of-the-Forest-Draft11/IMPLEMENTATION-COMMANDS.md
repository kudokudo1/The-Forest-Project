# Voice of the Forest Implementation Commands

## Detect repositories

```bash
if [[ -d "$HOME/Projects/project-digital-cross" ]]; then
    export PDC_ROOT="$HOME/Projects/project-digital-cross"
else
    export PDC_ROOT="$HOME/project-digital-cross"
fi

if [[ -d "$HOME/Projects/pdc-forest-language" ]]; then
    export FOREST_ROOT="$HOME/Projects/pdc-forest-language"
else
    export FOREST_ROOT="$HOME/pdc-forest-language"
fi
```

## Create the Voice directory and files

```bash
mkdir -p \
"$PDC_ROOT/heart/voice" \
"$PDC_ROOT/governance/specifications"

touch \
"$PDC_ROOT/heart/voice/VOICE-OF-THE-FOREST.yaml" \
"$PDC_ROOT/governance/specifications/FOREST-MAP-SPEC.md"
```

## Edit commands

```bash
nano "$FOREST_ROOT/language/FOREST-LANGUAGE.md"
nano "$PDC_ROOT/governance/specifications/FOREST-MAP-SPEC.md"
nano "$PDC_ROOT/heart/voice/VOICE-OF-THE-FOREST.yaml"
```

## Regenerate the Forest Map after editing

```bash
python3 "$PDC_ROOT/tools/UPDATE-FOREST-MAP.py" \
"$FOREST_ROOT/language/FOREST-LANGUAGE.md"
```
