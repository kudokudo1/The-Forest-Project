# Bristlecone Pine Seed Manifest

Seed package: Bristlecone Pine
Tree version: 0.0.1
Identity seed version: 0.0.2
Role: Treewright
Author: maciono brown
Status: Working seed; not yet a canonical Forest release

## Purpose

This package plants Bristlecone Pine as a separate Hermes profile with:

- a durable SOUL identity;
- a Treewright development skill;
- fresh memories and sessions;
- the current Hermes model and provider configuration cloned from the active
  default profile;
- a separate workspace;
- command aliases for `bristlecone-pine` and `bristlecone`.

## Initial model state

The planting process inherits the model/provider configuration already working
in the current Hermes profile. It does not yet implement Bristlecone's planned
multi-model router. The first planted version can operate immediately while the
router and specialist-model pool are developed.

## Not included yet

- Forest Constitution;
- Forest Principles;
- full Forest Language corpus;
- model router;
- independent reviewer models;
- training dataset store;
- formal Action Broker;
- filesystem sandbox;
- automatic canonical-learning pipeline.

These should be added as governed development stages after the first planting.
