#!/usr/bin/env bash
set -euo pipefail

PROFILE_HOME="${HOME}/.hermes/profiles/bristlecone"
WORKSPACE="${HOME}/The-Forest/bristlecone"

echo "=== PROFILE ==="
hermes profile show bristlecone

echo
echo "=== REQUIRED FILES ==="
for item in \
  "${PROFILE_HOME}/SOUL.md" \
  "${WORKSPACE}/AGENTS.md" \
  "${WORKSPACE}/seed-manifest.json" \
  "${WORKSPACE}/FIRST-CONVERSATION.txt" \
  "${WORKSPACE}/corpus" \
  "${WORKSPACE}/proposals" \
  "${WORKSPACE}/evaluations" \
  "${WORKSPACE}/receipts" \
  "${WORKSPACE}/learning/candidates" \
  "${WORKSPACE}/learning/approved"
do
  if [[ -e "${item}" ]]; then
    echo "OK   ${item}"
  else
    echo "MISS ${item}"
  fi
done

echo
echo "=== MODEL SERVICE ==="
ollama list

echo
echo "Verification finished. This script does not modify the profile."
