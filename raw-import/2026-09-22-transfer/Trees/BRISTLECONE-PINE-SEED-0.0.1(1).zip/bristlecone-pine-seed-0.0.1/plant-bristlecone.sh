#!/usr/bin/env bash
set -euo pipefail

PROFILE="bristlecone"
WORKSPACE="${HOME}/The-Forest/bristlecone"
PROFILE_HOME="${HOME}/.hermes/profiles/${PROFILE}"
STAMP="$(date +%Y%m%d-%H%M%S)"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Bristlecone Pine planting ==="

command -v hermes >/dev/null || {
  echo "Hermes is not available in PATH."
  exit 1
}

mkdir -p "${HOME}/The-Forest/backups"

if [[ -d "${PROFILE_HOME}" ]]; then
  echo "Profile '${PROFILE}' already exists."
  echo "Creating a safety export before updating seed files..."
  hermes profile export "${PROFILE}" \
    -o "${HOME}/The-Forest/backups/bristlecone-before-seed-${STAMP}.tar.gz"
else
  echo "Creating separate Hermes profile '${PROFILE}'..."
  hermes profile create "${PROFILE}" \
    --description "Forest-aware multi-model Treewright for Tree, plugin, add-on, training, coding, testing, and standards development."
fi

echo "Creating workspace at ${WORKSPACE}..."
mkdir -p "${WORKSPACE}"
cp -a "${SCRIPT_DIR}/workspace/." "${WORKSPACE}/"

if [[ -f "${PROFILE_HOME}/SOUL.md" ]]; then
  cp -a "${PROFILE_HOME}/SOUL.md" \
    "${HOME}/The-Forest/backups/bristlecone-SOUL-before-${STAMP}.md"
fi

cp "${SCRIPT_DIR}/SOUL.md" "${PROFILE_HOME}/SOUL.md"
cp "${SCRIPT_DIR}/seed-manifest.json" "${WORKSPACE}/seed-manifest.json"
cp "${SCRIPT_DIR}/FIRST-CONVERSATION.txt" "${WORKSPACE}/FIRST-CONVERSATION.txt"

bristlecone config set terminal.cwd "${WORKSPACE}"

echo
echo "Planting files complete."
echo "Next: run 'bristlecone model' and select your local Ollama endpoint."
echo "Then start a clean session with: bristlecone chat"
echo "Workspace: ${WORKSPACE}"
echo "Profile:   ${PROFILE_HOME}"
