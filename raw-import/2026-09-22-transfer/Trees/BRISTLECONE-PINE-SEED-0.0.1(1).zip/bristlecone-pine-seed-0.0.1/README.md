# Bristlecone Pine Seed 0.0.1

This package plants Bristlecone Pine as a separate Hermes profile and creates a dedicated development workspace.

It does not install a model, overwrite the default Hermes profile, or copy secrets.

## Package contents

- `SOUL.md` — Bristlecone's durable identity
- `workspace/AGENTS.md` — project and development rules
- `workspace/` — isolated working structure
- `seed-manifest.json` — seed identity and package metadata
- `plant-bristlecone.sh` — planting helper
- `verify-bristlecone.sh` — read-only verification helper

## Planting

Extract the ZIP, open a terminal in the extracted directory, then run:

```bash
chmod +x plant-bristlecone.sh verify-bristlecone.sh
./plant-bristlecone.sh
```

After planting, configure the local model:

```bash
bristlecone model
```

Choose a custom/OpenAI-compatible endpoint and use:

- Base URL: `http://localhost:11434/v1`
- API key: `ollama`
- Model: `qwen3:8b`

Use a context value that your local Ollama configuration can actually support. Do not claim a larger context than the server is configured to provide.

Start a new session:

```bash
bristlecone chat
```

The first test prompt is stored in `FIRST-CONVERSATION.txt`.
