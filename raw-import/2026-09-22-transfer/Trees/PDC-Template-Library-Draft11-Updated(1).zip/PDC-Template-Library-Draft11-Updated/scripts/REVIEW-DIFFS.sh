#!/usr/bin/env bash
set -euo pipefail

LIB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ -d "$HOME/Projects/project-digital-cross" ]]; then
  PDC_ROOT="${PDC_ROOT:-$HOME/Projects/project-digital-cross}"
else
  PDC_ROOT="${PDC_ROOT:-$HOME/project-digital-cross}"
fi

if [[ -d "$HOME/Projects/pdc-forest-language" ]]; then
  FOREST_ROOT="${FOREST_ROOT:-$HOME/Projects/pdc-forest-language}"
else
  FOREST_ROOT="${FOREST_ROOT:-$HOME/pdc-forest-language}"
fi

git diff --no-index -- \
  "$PDC_ROOT/templates" \
  "$LIB_ROOT/targets/project-digital-cross/templates" || true

git diff --no-index -- \
  "$FOREST_ROOT" \
  "$LIB_ROOT/targets/pdc-forest-language" || true
