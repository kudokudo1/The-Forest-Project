#!/usr/bin/env bash
set -euo pipefail

MODE="${1:---dry-run}"
case "$MODE" in
  --dry-run|--apply) ;;
  *) echo "Usage: $0 [--dry-run|--apply]"; exit 2 ;;
esac

LIB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

detect_dir() {
  local first="$1" second="$2"
  if [[ -d "$first" ]]; then
    printf '%s\n' "$first"
  elif [[ -d "$second" ]]; then
    printf '%s\n' "$second"
  else
    return 1
  fi
}

PDC_ROOT="${PDC_ROOT:-$(detect_dir "$HOME/Projects/project-digital-cross" "$HOME/project-digital-cross" || true)}"
FOREST_ROOT="${FOREST_ROOT:-$(detect_dir "$HOME/Projects/pdc-forest-language" "$HOME/pdc-forest-language" || true)}"

[[ -n "$PDC_ROOT" && -d "$PDC_ROOT" ]] || { echo "PDC repository not found."; exit 1; }
[[ -n "$FOREST_ROOT" && -d "$FOREST_ROOT" ]] || { echo "Forest Language repository not found."; exit 1; }

STAMP="$(date +%Y%m%d-%H%M%S)"
PDC_BACKUP="$PDC_ROOT/leaf-litter/superseded/template-replacements/$STAMP"
FOREST_BACKUP="$FOREST_ROOT/leaf-litter/superseded/template-replacements/$STAMP"

log() { printf '%s\n' "$*"; }

replace_with_backup() {
  local src="$1" dst="$2" backup_root="$3" rel="$4"
  if [[ "$MODE" == "--dry-run" ]]; then
    if [[ -e "$dst" ]]; then
      log "[REPLACE] $dst  (backup -> $backup_root/$rel)"
    else
      log "[INSTALL] $dst"
    fi
    return
  fi

  mkdir -p "$(dirname "$dst")"
  if [[ -e "$dst" ]]; then
    mkdir -p "$backup_root/$(dirname "$rel")"
    cp -a "$dst" "$backup_root/$rel"
  fi
  cp -a "$src" "$dst"
}

stage_candidate() {
  local src="$1" dst="$2"
  local candidate="${dst}.draft11-candidate"
  if [[ "$MODE" == "--dry-run" ]]; then
    log "[CANDIDATE] $candidate"
    return
  fi
  mkdir -p "$(dirname "$candidate")"
  cp -a "$src" "$candidate"
}

# Forest Language files are reviewable documents and templates.
while IFS= read -r -d '' src; do
  rel="${src#"$LIB_ROOT/targets/pdc-forest-language/"}"
  replace_with_backup "$src" "$FOREST_ROOT/$rel" "$FOREST_BACKUP" "$rel"
done < <(find "$LIB_ROOT/targets/pdc-forest-language" -type f -print0)

# PDC files: stage stateful files as candidates; replace templates/specs/schemas with backups.
while IFS= read -r -d '' src; do
  rel="${src#"$LIB_ROOT/targets/project-digital-cross/"}"
  dst="$PDC_ROOT/$rel"

  case "$rel" in
    governance/index/*|\
    heart/roots/root-map.yaml|\
    governance/relationships/relationship-types.yaml|\
    trees/*/TREE.yaml|\
    trees/*/grain/grain.yaml|\
    trees/*/reasoning/reasoning-profile.yaml)
      stage_candidate "$src" "$dst"
      ;;
    *)
      replace_with_backup "$src" "$dst" "$PDC_BACKUP" "$rel"
      ;;
  esac
done < <(find "$LIB_ROOT/targets/project-digital-cross" -type f -print0)

if [[ "$MODE" == "--dry-run" ]]; then
  log
  log "Dry run complete. Nothing was changed."
else
  log
  log "Apply complete."
  log "PDC backups: $PDC_BACKUP"
  log "Forest backups: $FOREST_BACKUP"
  log "Stateful files were staged as .draft11-candidate files."
fi
