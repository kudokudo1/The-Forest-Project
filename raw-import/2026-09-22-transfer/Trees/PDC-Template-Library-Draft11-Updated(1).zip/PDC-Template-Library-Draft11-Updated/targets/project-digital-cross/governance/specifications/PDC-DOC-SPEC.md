---
PDC-ID: "PDC-DOC-SPEC"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Document Specification"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🧭"
Forest-Layer: "Compass"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# PDC-DOC-SPEC — Universal Document Specification

## Purpose

Define the shared metadata and structural contract inherited by Project Digital Cross document types.

## Required Triple Identity

| Field | Meaning |
|---|---|
| PDC-ID | Stable human-readable identifier |
| UUID | Immutable machine identity |
| Canonical-Path | Repository-relative location |

## Required Metadata

- Title
- Record-Type
- Version
- Status
- Classification
- Priority
- Season
- Growth-Ring
- Author
- Custodian
- Created
- Last-Updated
- Forest-Symbol
- Forest-Layer
- Relationships
- Tags

## Required Common Sections

1. Purpose
2. Record-specific content
3. Paths or Relationships
4. Revision History
5. Forest Compass inscription

## Inheritance

Record-specific Specifications MAY add required sections and validation rules but MUST NOT remove the Triple Identity System or closing inscription.

## Validation

- Metadata parses as YAML.
- UUID is valid and unique.
- PDC-ID is unique within its record family.
- Canonical path exists and is registered.
- Paths resolve.
- Required sections are present.
- Footer matches the approved Forest Compass inscription.

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
