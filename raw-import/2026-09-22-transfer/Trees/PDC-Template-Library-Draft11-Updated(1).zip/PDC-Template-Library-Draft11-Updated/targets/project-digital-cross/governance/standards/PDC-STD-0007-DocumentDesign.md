---
PDC-ID: "PDC-STD-0007"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "PDC Standard"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🧭"
Forest-Layer: "Compass"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# PDC-STD-0007 — Document Design

## Purpose

Define the shared style and structural rules for official Project Digital Cross Markdown documents.

## Requirements

1. Every governed document MUST include the Triple Identity System:
   - PDC-ID
   - UUID
   - Canonical Path
2. Governed record prefixes MUST remain uppercase.
3. Directories and ordinary machine-readable filenames MAY remain lowercase.
4. Every document MUST state Version, Status, Season, Growth Ring, Author, Created, and Last Updated.
5. Reader-facing cross-references MUST use `Path to <PDC-ID>`.
6. Every official document MUST end with the Forest Compass inscription.
7. README files MUST be shown last in repository diagrams unless accessibility or platform behavior requires otherwise.
8. Technical meaning MUST remain available beneath Forest terminology.
9. Markdown heading levels MUST not skip levels.
10. Tables and code blocks MUST remain readable in plain text.

## Accessibility

- Do not rely on emoji alone to convey meaning.
- Use clear text labels with symbols.
- Avoid decorative formatting that harms screen-reader navigation.
- Keep tables and line lengths reasonably readable.

## Conformance

A document conforms when its required metadata, sections, Paths, revision history, and inscription are present and valid.

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
