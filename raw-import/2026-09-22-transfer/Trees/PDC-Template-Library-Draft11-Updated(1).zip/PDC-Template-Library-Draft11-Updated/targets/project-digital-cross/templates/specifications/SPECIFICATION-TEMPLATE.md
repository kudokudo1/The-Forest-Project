---
PDC-ID: "<PREFIX>-SPEC"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Specification"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🌱"
Forest-Layer: "Roots"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# <PREFIX>-SPEC — <SPECIFICATION TITLE>

## Purpose

Define what makes this artifact type valid.

## Applies To

- <FILE OR RECORD TYPE>

## Required Metadata

| Field | Required | Format | Meaning |
|---|---:|---|---|
| PDC-ID | Yes | `<PREFIX>-NNNN` | Human-readable identity |
| UUID | Yes | UUIDv4 | Immutable machine identity |
| Canonical-Path | Yes | Repository-relative path | Repository identity |

## Required Sections

1. <SECTION>
2. <SECTION>

## Optional Sections

- <SECTION>

## Prohibited Content

- <CONTENT THAT DOES NOT BELONG IN THIS TYPE>

## Lifecycle

```text
Draft -> Proposed -> Accepted -> Superseded -> Archived
```

## Numbering and Naming

```text
<PREFIX>-0001-Readable-Title.md
```

## Validation Rules

1. <RULE>

## Paths

- Path to <PDC-ID>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
