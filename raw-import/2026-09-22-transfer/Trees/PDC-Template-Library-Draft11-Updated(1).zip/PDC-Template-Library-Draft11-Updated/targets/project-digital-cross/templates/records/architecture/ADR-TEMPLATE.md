---
PDC-ID: "ADR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Architecture Decision Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🌿"
Forest-Layer: "Branch"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# ADR-XXXX — <DECISION TITLE>

## Context

Describe the situation, constraints, forces, and governing Roots.

## Problem Statement

State the architectural problem being decided.

## Decision

State the chosen architecture clearly.

## Decision Drivers

- <DRIVER>

## Alternatives Considered

### Option A — <NAME>

**Benefits**

- <BENEFIT>

**Costs / Risks**

- <COST>

### Option B — <NAME>

**Benefits**

- <BENEFIT>

**Costs / Risks**

- <COST>

## Consequences

### Positive

- <POSITIVE CONSEQUENCE>

### Negative

- <NEGATIVE CONSEQUENCE>

### Accepted Trade-offs

- <TRADE-OFF>

## Implementation Guidance

Describe what future implementations must preserve without turning this ADR into a procedure.

## Reversal or Supersession Conditions

Describe evidence that would justify revisiting the decision.

## Paths

- Path to <PR>
- Path to <ICR OR RCR>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
