---
PDC-ID: "<HUMAN-ID>"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "<RECORD-TYPE>"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "<SYMBOL>"
Forest-Layer: "<LAYER>"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# <TITLE>

## Purpose

State why this record exists and what it is intended to preserve, govern, explain, request, or change.

## Summary

Provide a brief overview that can be understood without reading the entire record.

## Scope

### Included

- <ITEM>

### Excluded

- <ITEM>

## Content

Write the record-specific content here.

## Forest Metadata

### Roots

- Path to <PDC-ID> — <WHY IT GOVERNS OR SUPPORTS THIS RECORD>

### Leaves

- <EVIDENCE OR SOURCE USED>

### Buds

- <POSSIBILITY LEFT OPEN>

### Blossoms

- <DRAFT OR PROPOSAL PRODUCED>

### Fruit

- <FINAL DELIVERABLE OR RESULT>

### Leaf Litter

- <DISCARDED OR SUPERSEDED ITEM AND LESSON>

## Relationships

### Paths

- Path to <PDC-ID>

### Dependencies

- <DEPENDENCY>

### Conflicts

- <KNOWN CONFLICT OR "None">

## Validation

- [ ] PDC-ID assigned
- [ ] UUID generated and registered
- [ ] Canonical path registered
- [ ] Required Roots checked
- [ ] Paths resolve
- [ ] References verified
- [ ] Status and version updated
- [ ] Revision history updated

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
