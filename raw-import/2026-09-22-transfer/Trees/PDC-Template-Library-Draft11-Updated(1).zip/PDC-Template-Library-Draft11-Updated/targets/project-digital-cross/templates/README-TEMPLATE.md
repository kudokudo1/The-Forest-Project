# <DIRECTORY OR REPOSITORY NAME>

## Purpose

Explain what belongs here and why this area exists.

## Authority

State which Constitution, Standard, Specification, or Record governs this area.

## Contents

| Path | Purpose |
|---|---|
| `<PATH>` | <PURPOSE> |

## What Belongs Here

- <ITEM>

## What Does Not Belong Here

- <ITEM>

## Naming Rules

- <RULE>

## Paths

- Path to <PDC-ID>

## Maintenance

- Custodian:
- Review cadence:
- Current Season:
- Current Growth Ring:

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
