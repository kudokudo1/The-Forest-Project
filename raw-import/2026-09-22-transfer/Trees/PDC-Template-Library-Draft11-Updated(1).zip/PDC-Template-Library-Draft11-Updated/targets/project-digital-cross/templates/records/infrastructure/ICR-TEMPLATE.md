---
PDC-ID: "ICR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Infrastructure Change Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🌊"
Forest-Layer: "Stream"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# ICR-XXXX — <INFRASTRUCTURE CHANGE TITLE>

## Change Summary

Summarize the infrastructure change.

## Reason

Explain why the change was necessary.

## Affected Earth, Services, or Streams

- <SYSTEM OR SERVICE>

## Previous State

Describe the known configuration before the change.

## Planned Change

Describe the exact intended change.

## Preconditions

- [ ] Backup or rollback data available
- [ ] Dependencies identified
- [ ] Required access confirmed
- [ ] Maintenance risk understood

## Change Procedure

1. <STEP>
2. <STEP>

## Verification

1. <TEST>
2. <TEST>

## Rollback Plan

1. <ROLLBACK STEP>
2. <ROLLBACK STEP>

## Actual Result

Record what actually happened, including deviations.

## Leaf Litter Created

- <REMOVED OR SUPERSEDED CONFIGURATION>

## Lessons

- <LESSON>

## Paths

- Path to <ADR>
- Path to <SCR OR NCR>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
