---
PDC-ID: "RCR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Request Change Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🌱"
Forest-Layer: "Bud"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# RCR-XXXX — <CHANGE REQUEST TITLE>

## Request

State the requested change.

## Requester

- Name:
- Role:
- Date:

## Motivation

Explain the need, pain point, opportunity, or risk.

## Desired Outcome

Describe success without prematurely prescribing implementation.

## Scope

### Included

- <ITEM>

### Excluded

- <ITEM>

## Buds

List candidate approaches without selecting one yet.

1. <APPROACH>

## Impact Areas

- [ ] Constitution
- [ ] Standards
- [ ] Specifications
- [ ] Principles
- [ ] Architecture
- [ ] Infrastructure
- [ ] Networking
- [ ] Security
- [ ] Memory
- [ ] Operations
- [ ] Trees
- [ ] Bark
- [ ] Forest Language

## Review

### Benefits

- <BENEFIT>

### Costs and Risks

- <COST OR RISK>

### Dependencies

- <DEPENDENCY>

## Decision

- [ ] Pending
- [ ] Approved
- [ ] Rejected
- [ ] Deferred
- [ ] Superseded

### Decision Rationale

<RATIONALE>

## Resulting Paths

- Path to <PR, ADR, ICR, SCR, NCR, MRR, OR OPR>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
