---
PDC-ID: "SCR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Security Change Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "❤️"
Forest-Layer: "Heart"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# SCR-XXXX — <SECURITY CHANGE TITLE>

## Security Objective

State what security property this change protects.

## Threat or Risk

Describe the threat, exposure, weakness, or compliance concern.

## Scope

- <SYSTEM, IDENTITY, TREE, EARTH, STREAM, OR RECORD>

## Current Controls

- <CONTROL>

## Change

Describe the security change.

## Access and Authority

Identify who or what may approve, execute, review, and reverse the change.

## Secrets Handling

Do not place secrets in this record. Document only the approved storage and retrieval method.

## Verification

- [ ] Access tested
- [ ] Authentication or MFA tested
- [ ] Logging verified
- [ ] Recovery verified
- [ ] Least privilege reviewed

## Incident / Rollback Plan

Describe containment and rollback steps.

## Residual Risk

- <RISK THAT REMAINS>

## Paths

- Path to <PR>
- Path to <ADR>
- Path to <ICR>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
