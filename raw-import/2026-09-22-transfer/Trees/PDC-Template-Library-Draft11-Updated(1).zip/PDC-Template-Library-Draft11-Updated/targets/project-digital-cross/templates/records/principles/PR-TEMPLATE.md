---
PDC-ID: "PR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Principle Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🌱"
Forest-Layer: "Roots"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# PR-XXXX — <PRINCIPLE TITLE>

## Principle

> <ONE-SENTENCE PRINCIPLE>

## Purpose

Explain why this Principle is necessary.

## Rationale

Explain the values, risks, and long-term goals behind it.

## Required Behavior

- <WHAT THIS PRINCIPLE REQUIRES>

## Violations

- <EXAMPLE OF MISALIGNED BEHAVIOR>

## Examples

### Aligned

- <EXAMPLE>

### Misaligned

- <EXAMPLE>

## Implications

Explain how the Principle affects architecture, operations, Trees, contributors, and users.

## Paths

- Path to <ADR OR STANDARD>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
