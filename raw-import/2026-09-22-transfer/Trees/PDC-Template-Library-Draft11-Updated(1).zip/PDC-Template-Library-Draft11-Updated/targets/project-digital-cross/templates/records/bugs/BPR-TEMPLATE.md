---
PDC-ID: "BPR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Bug and Postmortem Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🍂"
Forest-Layer: "Leaf-Litter"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# BPR-XXXX — <BUG OR INCIDENT TITLE>

## Summary

Describe what failed and its effect.

## Detection

Explain how the issue was discovered.

## Impact

- Users affected:
- Trees affected:
- Earths affected:
- Data affected:
- Duration:

## Timeline

| Time | Event |
|---|---|
| <TIME> | <EVENT> |

## Symptoms

- <SYMPTOM>

## Root Cause

Explain technical and process causes. Distinguish true Roots from surface symptoms.

## Contributing Factors

- <FACTOR>

## Resolution

Describe what restored service or corrected the defect.

## Verification

- <TEST>

## Leaf Litter

List broken, discarded, or superseded files and components.

## Lessons

- <LESSON>

## Corrective Actions

| Action | Owner | Status | Path |
|---|---|---|---|
| <ACTION> | <OWNER> | <STATUS> | Path to <RECORD> |

## Paths

- Path to <ADR>
- Path to <ICR>
- Path to <SCR>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
