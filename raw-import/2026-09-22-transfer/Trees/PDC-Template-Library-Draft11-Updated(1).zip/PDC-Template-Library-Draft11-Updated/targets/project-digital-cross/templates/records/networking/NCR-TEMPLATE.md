---
PDC-ID: "NCR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Network Change Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🌊"
Forest-Layer: "Stream"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# NCR-XXXX — <NETWORK CHANGE TITLE>

## Network Objective

State the connectivity or isolation goal.

## Scope

- <EARTH>
- <NETWORK>
- <STREAM>
- <SERVICE>

## Current Topology

Describe the known current state.

## Proposed Topology

Describe the intended state.

## Addresses, Ports, and Protocols

| Component | Address / Name | Port | Protocol | Direction |
|---|---|---:|---|---|
| <COMPONENT> | <VALUE> | <PORT> | <PROTOCOL> | <IN/OUT/BOTH> |

## Trust Boundaries

- <BOUNDARY>

## Change Procedure

1. <STEP>

## Validation

- [ ] Connectivity tested
- [ ] Isolation tested
- [ ] DNS tested
- [ ] Firewall rules reviewed
- [ ] Remote access tested
- [ ] Rollback documented

## Rollback

1. <STEP>

## Paths

- Path to <ADR>
- Path to <SCR>
- Path to <ICR>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
