---
PDC-ID: "OPR-XXXX"
UUID: "<GENERATE-UUID>"
Canonical-Path: "<REPOSITORY-RELATIVE-PATH>"

Title: "<TITLE>"
Record-Type: "Operational Procedure Record"
Version: "0.1.0"
Status: "Draft"
Classification: "Internal"
Priority: "Normal"

Season: "<Spring|Summer|Autumn|Winter>"
Growth-Ring: "<DRAFT-OR-MILESTONE>"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🧭"
Forest-Layer: "Compass"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags: []
---
# OPR-XXXX — <PROCEDURE TITLE>

## Objective

State the operational outcome.

## When to Use

- <TRIGGER OR CONDITION>

## When Not to Use

- <CONDITION>

## Required Access and Tools

- <ACCESS OR TOOL>

## Preconditions

- [ ] <CHECK>

## Procedure

1. <STEP>
2. <STEP>

## Expected Result

Describe what success looks like.

## Verification

1. <CHECK>

## Failure Handling

Describe what to do if a step fails.

## Rollback or Recovery

1. <STEP>

## Evidence to Record

- <LOG, SCREENSHOT, HASH, TEST, OR CHANGE RECORD>

## Paths

- Path to <ICR>
- Path to <SCR>
- Path to <NCR>

## Revision History

| Version | Date | Author | Summary |
|---|---|---|---|
| 0.1.0 | <YYYY-MM-DD> | maciono brown | Initial working draft |

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
