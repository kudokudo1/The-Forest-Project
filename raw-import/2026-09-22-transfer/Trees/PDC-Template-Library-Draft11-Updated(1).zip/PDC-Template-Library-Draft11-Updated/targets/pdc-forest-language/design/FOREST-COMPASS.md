# Forest Compass

The Forest Compass is the navigation and orientation component used in Project Digital Cross documents.

## Canonical Inscription

> *This record is written to be your guide and map through the Forest.*
>
> *It grows as you walk.*

The wording is intentionally ambiguous, mysterious, and cautionary.

It signals that:

- The Forest expands as people explore and interact with it.
- Trees grow faster when used, cared for, corrected, and fed knowledge.
- Records may lead into deeper nested Paths and Roots.
- The reader is entering a layered language and architecture.
- Exploration changes both the map and the Forest.

## Navigation Form

Use:

```text
Path to ADR-0004
```

instead of:

```text
Path to ADR-0004
```

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
