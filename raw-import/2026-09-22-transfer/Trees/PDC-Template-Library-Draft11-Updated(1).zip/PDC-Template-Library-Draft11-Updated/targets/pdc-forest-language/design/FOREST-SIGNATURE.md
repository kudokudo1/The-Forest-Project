# Forest Signature

The Forest Signature is the permanent identity statement placed near the bottom of every official Project Digital Cross document.

## Canonical Text

> **Project Digital Cross**
>
> *In God we trust.*  
> *In the Forest we wonder.*

The wording must not change without an approved governance change.

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
