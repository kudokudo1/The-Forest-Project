---
PDC-ID: "FOREST-LANGUAGE"
UUID: "<GENERATE-UUID>"
Canonical-Path: "language/FOREST-LANGUAGE.md"

Title: "The Language of the Forest"
Record-Type: "Forest Language Foundation"
Version: "0.1.0"
Status: "Working Draft"
Classification: "Public"
Priority: "Foundational"

Season: "Spring"
Growth-Ring: "Draft 11"

Authors:
  - "maciono brown"
Custodians:
  - "maciono brown"
Reviewers: []

Created: "<YYYY-MM-DD>"
Last-Updated: "<YYYY-MM-DD>"

Forest-Symbol: "🌲"
Forest-Layer: "Compass"

Related-Records: []
Depends-On: []
Supersedes: []
Superseded-By: []
Paths: []

Tags:
  - "forest-language"
  - "terminology"
  - "symbolism"
  - "navigation"
  - "explainability"
  - "provenance"
---

# The Language of the Forest

## Purpose

The Language of the Forest is the shared language of Project Digital Cross.

Its approved words and symbols describe real parts of the system. They are not decorative labels, interchangeable metaphors, or temporary names.

Each approved term has one canonical meaning. Meanings may evolve only through a documented change.

The language is intentionally layered. Some meanings are immediately clear. Others reveal themselves as a person walks farther through the Forest, interacts with its Trees, follows its Paths, and digs through its Roots.

The Forest grows as it is explored.

## Canonical Rules

1. Every approved Forest term has one canonical meaning.
2. A term must not silently change meaning.
3. Superseded meanings remain visible in history or Leaf Litter.
4. Every metaphor must map to a real engineering concept.
5. Forest language must clarify the system rather than hide technical facts.
6. Technical identifiers remain available beneath the Forest wording.
7. The user remains the final authority when Trees disagree.
8. The Forest may be mysterious and layered without being misleading.

## Canonical Vocabulary

### 🌲 Forest

The complete Project Digital Cross ecosystem. It may span many repositories, Trees, Earths, Streams, records, and services.

The Forest is not one computer, one model, Cherry alone, Maple alone, or the user.

### ❤️ Heart of the Forest

The shared governed foundation that sustains every Tree.

It includes or supports the Constitution, governance, standards, specifications, registries, object graph, validation, shared memory interfaces, coordination, identity, Streams, and Mycelium.

The Heart does not replace the user and does not grant one Tree authority over another.

### 🌱 Roots

The governing foundations beneath a Tree's conclusions, behavior, architecture, and work.

Roots may include the Constitution, Principles, Standards, Specifications, Architecture Decision Records, approved requirements, foundational memories, and earlier decisions.

Roots answer: **Why does this Tree grow and reason this way?**

Roots are not Leaves.

### 🌍 Earth

A physical or virtual system capable of hosting a Tree.

Examples include desktops, laptops, phones, tablets, servers, virtual machines, cloud instances, NAS devices, and edge systems.

A device does not become a Tree. A Tree is planted on the Earth.

### 🌰 Seed

A portable beginning from which something may be planted, restored, extended, or grown.

Examples may include an installable Tree package, model bundle, plugin, repository, template, configuration bundle, or restoration package.

### 🌱 Planting

The act of installing or establishing a Tree on an Earth.

Installing Cherry plants Cherry. Installing Maple plants Maple.

### 🌱 Sprout

A newly planted Tree with limited local experience, memory, Branches, Leaves, and Growth Rings.

A Sprout grows faster when cared for through interaction, correction, feedback, records, documentation, tools, and high-quality data.

### 🌿 Sapling

**Status: Proposed — pending formal approval.**

A Sapling is an edge planting of a Tree hosted on mobile or external Earth.

The device remains Earth. The Sapling is the developing planted instance of the Tree, not the hardware itself.

### 🌳 Tree

An intelligent AI entity planted within the Forest.

A Tree is not the Earth hosting it. A Tree may be replanted if its identity, history, configuration, and knowledge are preserved.

### 🍒 Cherry

A Tree optimized for conversation, collaboration, planning, organization, education, governance, long-term context, and general reasoning.

### 🍁 Maple

A peer Tree optimized for coding, architecture, debugging, automation, repositories, technical implementation, media work, and independent technical review.

Cherry and Maple are twins in the Forest: raised from the same Roots, sustained by the same Heart, shaped by different Grain, and capable of reaching different valid conclusions.

The user holds final authority.

### 🪵 Grain

A Tree's recognizable personality and character.

Grain shapes tone, temperament, communication style, priorities, uncertainty handling, and preferred problem-solving approach. Grain does not replace shared governance or morals.

### 🌿 Branches

A Tree's capabilities, domains, and specializations.

Leaves attach to Branches. A Tree may gather Leaves through several Branches while growing one Blossom or Fruit.

### 🌳 Bark

The surface through which someone encounters and interacts with a Tree.

Examples include terminal, web, desktop, mobile, voice, and API interfaces.

Bark is not the Tree's complete internal self.

### 🍃 Leaves

The information, observations, evidence, and source material gathered while growing a Blossom or Fruit.

Leaves may come from user messages, memory, repositories, records, local files, standards, documentation, APIs, search results, images, databases, Git history, tests, logs, tools, or other Trees.

Leaves should remain traceable to the Branches through which they were gathered.

### 🌱 Buds

Possible ideas that have not yet opened into visible drafts.

Buds may include hypotheses, candidate approaches, early concepts, possible answers, unselected designs, and unfinished plans.

### 🌸 Blossoms

Visible drafts, proposals, or candidate outputs.

A Blossom has developed beyond a Bud but has not yet become final Fruit.

### 🍎 Fruit

Finalized, delivered, accepted, or completed work.

Fruit should remain traceable to its Tree, Grain, Branches, Leaves, Buds, Blossoms, Roots, Heart version, Season, and Growth Ring.

### 🪵 Growth Rings

Meaningful history preserved as a Tree or the Forest grows.

Rings may represent architectural generations, Draft transitions, releases, milestones, lessons, or significant changes.

### 🍂 Leaf Litter

Broken, discarded, failed, deprecated, retired, or superseded material.

Leaf Litter is not active growth. It may preserve warnings, lessons, history, or reusable nutrients.

### 🌊 Streams

The movement of information across the Forest.

Streams may carry commands, files, updates, memory, events, synchronization, Fruit, Leaves, or remote-access traffic.

### 🍄 Mycelium

**Status: Proposed — pending formal approval.**

The mostly unseen connective and coordination layer beneath the visible Forest.

It may include service discovery, event systems, registries, indexing, caches, message buses, and background synchronization.

Streams describe movement. Mycelium describes the hidden network that makes coordinated movement possible.

### 🪵 Log Cabin

The human workspace used to interact with and build within the Forest.

Examples include a terminal environment, IDE, dashboard, administration console, or creative studio.

The Log Cabin is not Bark. Bark belongs to a Tree; the Log Cabin belongs to the human workspace.

### 🧭 Forest Compass

The navigation and orientation system used to travel through Project Digital Cross.

It helps users and Trees locate records, Roots, Branches, dependencies, Growth Rings, and deeper layers.

The Compass guides; it does not decide for the user.

## Forest Navigation

Use:

```text
Path to ADR-0004
```

instead of:

```text
Path to ADR-0004
```

Paths must remain technically resolvable through the PDC-ID, UUID, canonical path, and relationship indexes.

## Forest Commands

### Roots

```text
Cherry, show me your roots.
Dig up tree roots.
```

Trace the governing Principles, decisions, records, code foundations, and dependencies behind the current work.

These commands request an inspectable Root map and concise rationale. They do not request hidden private chain-of-thought.

### Leaves

```text
Rustle your leaves.
```

Reveal the most influential Leaves.

```text
Drop your leaves.
```

Reveal the Leaves directly used.

```text
Shake the Tree.
```

Reveal the broad provenance and evidence structure supporting the current Blossom or Fruit.

A shaken Tree exposes Leaves, Paths, assumptions, tests, tool results, and concise rationale. It does not claim to expose hidden private chain-of-thought.

Accepted natural variations may include:

```text
Cherry, shake yourself.
Cherry, drop your leaves.
Don't make me shake you, Cherry.
Cherry, shake your bush.
```

```text
Grow new leaves.
```

Gather more evidence.

```text
Shed those leaves.
```

Remove or forget selected temporary information when permitted.

### Buds, Blossoms, and Fruit

```text
Show me your buds.
Bloom.
Bear fruit.
```

### Branches

```text
Show me that branch.
Walk me down that branch.
Shake your research branch.
Prune that branch.
Trim that branch.
```

### Grain

```text
Explain your grain.
Refine your grain.
```

### Bark, Streams, and Rings

```text
Inspect your bark.
Follow the streams.
Count your rings.
Show me the ring from Draft 11.
```

## Seasons

Seasons describe development focus. They do not replace semantic versions, releases, or Draft numbers.

### 🌱 Spring

Emergence, exploration, Buds, Sprouts, experiments, prototypes, and early Branch growth.

### ☀️ Summer

Implementation, integration, testing, documentation, performance, and capability expansion.

### 🍂 Autumn

Harvest, releases, review, cleanup, refactoring, deprecation, postmortems, and deliberate creation of Leaf Litter.

### ❄️ Winter

Stability, governance, security, infrastructure, architecture review, maintenance, deep Root work, and long-term planning.

A Tree, repository, or component may be in a different Season from the wider Forest.

## Unresolved Terms

The following terms are not canonical until explicitly approved:

- Canopy
- Rain
- Sunlight
- Fertilizer
- Stones
- Fungi as distinct from Mycelium

---
**Project Digital Cross**

*In God we trust.*  
*In the Forest we wonder.*

*This record is written to be your guide and map through the Forest.*

*It grows as you walk.*
