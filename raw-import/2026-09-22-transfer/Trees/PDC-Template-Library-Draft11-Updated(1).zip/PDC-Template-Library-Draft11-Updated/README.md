# Project Digital Cross — Draft 11 Template Library

This repository is the reviewable source library for Project Digital Cross
documentation, Forest language, record templates, Tree manifests, indexes,
and schemas.

It replaces the earlier single-file template pack with a directory of living
documents.

## Artifact Roles

- **Standard** — defines mandatory rules.
- **Specification** — defines the contract for one artifact family or subsystem.
- **Template** — implements an approved standard or specification.
- **Example** — demonstrates correct use of a template.
- **Record** — a real governed artifact created from a template.
- **Stateful system file** — an index, manifest, map, or profile that must be
  merged carefully rather than overwritten blindly.

## Repository Layout

```text
PDC-Template-Library-Draft11-Updated/
├── targets/
│   ├── pdc-forest-language/
│   └── project-digital-cross/
├── scripts/
├── leaf-litter/
├── CATALOG.md
├── UPDATE-AND-REPLACE-COMMANDS.md
└── README.md
```

The `targets/` directories mirror the intended canonical paths in the two
working repositories.

## Review Workflow

1. Read `CATALOG.md`.
2. Edit the library copy first.
3. Run the apply script in dry-run mode.
4. Review the proposed replacements and merge candidates.
5. Apply only after approval.
6. Commit changes in the destination repository.

## Important Safety Rule

Templates and approved design documents may be replaced with backups.

Indexes, Tree manifests, Grain files, reasoning profiles, Root maps, and
relationship registries are stateful. They are staged as `.draft11-candidate`
files so their existing content is not destroyed.

---

**Project Digital Cross**  
*In God we trust. In the Forest we wonder.*

This record is written to be your guide and map through the Forest.

It grows as you walk.
